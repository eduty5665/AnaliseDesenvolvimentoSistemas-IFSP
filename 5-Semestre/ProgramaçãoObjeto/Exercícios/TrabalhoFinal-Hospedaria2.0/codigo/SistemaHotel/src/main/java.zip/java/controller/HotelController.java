package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import model.Cliente;
import model.Quarto;
import model.Reserva;


public class HotelController {
    private List<Cliente> clientes;
    private List<Quarto> quartos;
    private List<Reserva> reservas;

    public HotelController() {
        this(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
    }

    public HotelController(List<Cliente> clientes, List<Quarto> quartos, List<Reserva> reservas) {
        this.clientes = clientes;
        this.quartos = quartos;
        this.reservas = reservas;
    }
    
    public void adicionarCliente(Cliente cliente){
        clientes.add(cliente);
    }
    
    public List<Cliente> getClientes(){
        return clientes;
    }

    public Optional<Cliente> buscarClientePorId(int idCliente) {
        return clientes.stream()
                .filter(cliente -> cliente.getIdCliente() == idCliente)
                .findFirst();
    }
    
    public void adicionarQuarto(Quarto quarto){
        quartos.add(quarto);
    }
    
    public List<Quarto> getQuartos(){
        return quartos;
    }

    public Optional<Quarto> buscarQuartoPorNumero(int numero) {
        return quartos.stream()
                .filter(quarto -> quarto.getNumero() == numero)
                .findFirst();
    }

    public List<Quarto> getQuartosDisponiveis() {
        return quartos.stream()
                .filter(Quarto::isDisponivel)
                .toList();
    }
    
    public void adicionarReserva(Reserva reserva){
        reservas.add(reserva);
        reserva.getQuarto().setDisponivel(false);
    }
    
    public List<Reserva> getReservas(){
        return reservas;
    }

    public int contarQuartosDisponiveis() {
        return (int) quartos.stream()
                .filter(Quarto::isDisponivel)
                .count();
    }

    public double calcularReceitaTotal() {
        return reservas.stream()
                .mapToDouble(Reserva::calcularTotal)
                .sum();
    }
}
